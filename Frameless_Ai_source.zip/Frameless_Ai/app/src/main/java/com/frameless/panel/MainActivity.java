package com.frameless.panel;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Opens the Frameless_AI WebUI directly (no KernelSU WebUI / MMRL needed). Needs root. */
public class MainActivity extends Activity {
    static final String MODULE_WEBROOT = "/data/adb/modules/frameless_ai/webroot";
    WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#07040F"));
        w.setNavigationBarColor(Color.parseColor("#07040F"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#07040F"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.addJavascriptInterface(new Ksu(), "ksu");
        web.setWebViewClient(new WebViewClient());

        new Thread(() -> {
            File root = new File(getFilesDir(), "webroot");
            root.mkdirs();
            // 1) bundled copy (always works)
            for (String n : new String[]{"index.html", "banner.jpg"}) copyAsset(n, new File(root, n));
            // 2) newest copy from the installed module (root)
            String uid = String.valueOf(android.os.Process.myUid());
            sh("cp -f " + MODULE_WEBROOT + "/* " + root.getAbsolutePath() + "/ && chown -R " + uid + ":" + uid + " "
                    + root.getAbsolutePath() + " && chmod -R 755 " + root.getAbsolutePath());
            final boolean hasRoot = sh("id -u")[1].trim().equals("0");
            runOnUiThread(() -> {
                if (!hasRoot) Toast.makeText(this, "Root access is required (grant it in Magisk/KernelSU)", Toast.LENGTH_LONG).show();
                web.loadUrl("file://" + new File(root, "index.html").getAbsolutePath());
            });
        }).start();
    }

    void copyAsset(String name, File out) {
        try (InputStream in = getAssets().open("webroot/" + name); FileOutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        } catch (Exception ignored) { }
    }

    /** returns {code, stdout, stderr} of "su -c cmd" */
    static String[] sh(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            final ByteArrayOutputStream err = new ByteArrayOutputStream();
            Thread t = new Thread(() -> pipe(p.getErrorStream(), err));
            t.start();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            pipe(p.getInputStream(), out);
            int code = p.waitFor();
            t.join();
            return new String[]{String.valueOf(code), out.toString("UTF-8"), err.toString("UTF-8")};
        } catch (Exception e) {
            return new String[]{"1", "", String.valueOf(e)};
        }
    }

    static void pipe(InputStream in, ByteArrayOutputStream out) {
        try { byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) out.write(b, 0, n); } catch (Exception ignored) { }
    }

    /** Same API as KernelSU WebUI: ksu.exec(cmd, optionsJson, callbackName) */
    class Ksu {
        @JavascriptInterface
        public void exec(String cmd, String opts, String cb) {
            new Thread(() -> {
                String[] r = sh(cmd);
                String js = "window[" + JSONObject.quote(cb) + "]&&window[" + JSONObject.quote(cb) + "]("
                        + r[0] + "," + JSONObject.quote(r[1]) + "," + JSONObject.quote(r[2]) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
